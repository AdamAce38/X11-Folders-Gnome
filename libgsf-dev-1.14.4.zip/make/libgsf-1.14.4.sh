MOD=libgsf
VER=1.14.4
THIS=$MOD-$VER
HEX=`echo $THIS | md5sum | cut -d' ' -f1`
DEPS=`/devel/src/tml/latest.sh glib atk pango gtk+ libIDL ORBit2 libbonobo GConf gnome-vfs`
sed -e 's/need_relink=yes/need_relink=no # no way --tml/' <ltmain.sh >ltmain.temp && mv ltmain.temp ltmain.sh
for F in intltool-*.in; do
    sed -e 's!/dev/null!NUL:!g' <$F >$F.temp && mv $F.temp $F
done
usestable
unset MY_PKG_CONFIG_PATH
for D in $DEPS; do
    PATH=/devel/dist/$D/bin:$PATH
    MY_PKG_CONFIG_PATH=/devel/dist/$D/lib/pkgconfig:$MY_PKG_CONFIG_PATH
done
PKG_CONFIG_PATH=$MY_PKG_CONFIG_PATH:$PKG_CONFIG_PATH CC='gcc -mtune=pentium3' CPPFLAGS='-I/opt/gnu/include -I/opt/misc/include -I/opt/gnuwin32/include -I/devel/dist/popt-1.10.2-tml-20050828/include' LDFLAGS='-L/opt/gnu/lib -L/opt/misc/lib -L/opt/gnuwin32/lib -L/devel/dist/popt-1.10.2-tml-20050828/lib' CFLAGS=-O ./configure --disable-gtk-doc --disable-static --prefix=c:/devel/target/$HEX --without-python
# Do NOT use libtool-cache for libgsf! It breaks build in tools
make -j3 install &&
PATH=/devel/target/$HEX/bin:$PATH make check &&
./libgsf-zip &&
(cd /devel/src/tml && zip /tmp/$MOD-dev-$VER.zip make/$THIS.sh) &&
manifestify /tmp/$MOD*-$VER.zip
