# This is a shell script that calls functions and scripts from
# tml@iki.fi's personal work env�ronment. It is not expected to be
# usable unmodified by others, and is included only for reference.

MOD=ORBit2
VER=2.14.13
THIS=$MOD-$VER
HEX=`echo $THIS | md5sum | cut -d' ' -f1`

DEPS=`/devel/src/tml/latest.sh glib libIDL`

baseverlen=`expr match $VER '[0-9]*\.[0-9]*\.[0-9]*'`
basever=`expr substr $VER 1 $baseverlen`

sed -e 's/need_relink=yes/need_relink=no # no way --tml/' <ltmain.sh >ltmain.temp && mv ltmain.temp ltmain.sh

patch -p0 <<'EOF'
Index: src/orb/GIOP/giop-send-buffer.c
===================================================================
--- src/orb/GIOP/giop-send-buffer.c	(revision 2069)
+++ src/orb/GIOP/giop-send-buffer.c	(working copy)
@@ -455,6 +455,9 @@
 	   &&|| giop_send_buffer_align (buf, 8); */
 
 	if (g_thread_supported () 
+#ifdef G_OS_WIN32
+	    && (lcnx->remote_host_info != NULL && strcmp (lcnx->remote_host_info, "127.0.0.1") != 0)
+#endif
 	    && lcnx->timeout_msec 
 	    && !lcnx->timeout_source_id
 	    && !giop_send_buffer_is_oneway (buf)) {
EOF

usestable

unset MY_PKG_CONFIG_PATH
for D in $DEPS; do
    PATH=/devel/dist/$D/bin:$PATH
    MY_PKG_CONFIG_PATH=/devel/dist/$D/lib/pkgconfig:$MY_PKG_CONFIG_PATH
done

PKG_CONFIG_PATH=$MY_PKG_CONFIG_PATH:$PKG_CONFIG_PATH CC='gcc -mtune=pentium3 -mthreads' CPPFLAGS='-I/opt/gnu/include' LDFLAGS='-L/opt/gnu/lib' CFLAGS=-O2 ./configure  --enable-debug=yes --disable-gtk-doc --disable-static --prefix=c:/devel/target/$HEX &&
libtoolcacheize &&
unset MY_PKG_CONFIG_PATH &&

PATH=/devel/target/$HEX/bin:.libs:$PATH make install &&

# rm .libtool-cache-link-exe &&
# (cd test && PATH=/devel/target/$HEX/bin:$PATH make check) &&

./ORBit2-zip &&

( (
[ $VER != $basever ] && {
mv /tmp/$MOD-$basever.zip /tmp/$MOD-$VER.zip &&
mv /tmp/$MOD-dev-$basever.zip /tmp/$MOD-dev-$VER.zip
}
) || true) &&

(cd /devel/src/tml && zip /tmp/$MOD-dev-$VER.zip make/$THIS.sh) &&
manifestify /tmp/$MOD*-$VER.zip
