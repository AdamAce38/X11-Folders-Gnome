/* gdkconfig.h
 *
 * This is a generated file.  Please modify `configure.in'
 */

#ifndef GDKCONFIG_H
#define GDKCONFIG_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define GDK_WINDOWING_WIN32

#define GDK_HAVE_WCHAR_H 1
#define GDK_HAVE_WCTYPE_H 1
#define GDK_HAVE_BROKEN_WCTYPE 1

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GDKCONFIG_H */
