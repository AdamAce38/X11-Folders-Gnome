#ifndef CORBA_TYPECODE_TYPE_H
#define CORBA_TYPECODE_TYPE_H 1

#include <glib.h>

G_BEGIN_DECLS

#if !defined(ORBIT_DECL_CORBA_TypeCode) && !defined(_CORBA_TypeCode_defined)
#define ORBIT_DECL_CORBA_TypeCode 1
#define _CORBA_TypeCode_defined 1
typedef struct CORBA_TypeCode_struct *CORBA_TypeCode;
#endif

G_END_DECLS

#endif
