# This is a shell script that calls functions and scripts from
# tml@iki.fi's personal work environment. It is not expected to be
# usable unmodified by others, and is included only for reference.

MOD=evolution
VER=2.24.2
REV=1
ARCH=win32

THIS=${MOD}_${VER}-${REV}_${ARCH}

RUNZIP=${MOD}_${VER}-${REV}_${ARCH}.zip
DEVZIP=${MOD}-dev_${VER}-${REV}_${ARCH}.zip

HEX=`echo $THIS | md5sum | cut -d' ' -f1`
TARGET=c:/devel/target/$HEX

usedev
usemsvs6

(

set -x

DEPS=`latest --arch=${ARCH} gnome-doc-utils intltool glib enchant atk pango pixman libpng cairo gtk+ libxml2 libglade libIDL ORBit2 libbonobo GConf libbonoboui gnome-mime-data libgnome libgnomeui gnome-vfs gnutls libsoup evolution-data-server gnome-icon-theme fontconfig freetype libart-lgpl libgnomecanvas iso-codes gtkhtml shared-mime-info sqlite3`
PROXY_LIBINTL=`latest --arch=${ARCH} proxy-libintl`
WIN_ICONV=`latest --arch=${ARCH} win-iconv`
POPT=`latest --arch=${ARCH} popt`
LIBGNURX=`latest --arch=${ARCH} libgnurx`
ZLIB=`latest --arch=${ARCH} zlib`
NSPR=`latest --arch=${ARCH} mozilla-nspr`
NSS=`latest --arch=${ARCH} mozilla-nss`
PTHREADS=`latest --arch=${ARCH} pthreads-win32`

PKG_CONFIG_PATH=/dummy
for D in $DEPS; do
    PATH=/devel/dist/${ARCH}/$D/bin:$PATH
    [ -d /devel/dist/${ARCH}/$D/lib/pkgconfig ] && PKG_CONFIG_PATH=/devel/dist/${ARCH}/$D/lib/pkgconfig:$PKG_CONFIG_PATH
    [ -d /devel/dist/${ARCH}/$D/share/pkgconfig ] && PKG_CONFIG_PATH=/devel/dist/${ARCH}/$D/share/pkgconfig:$PKG_CONFIG_PATH
done

# Don't do any relinking crap in libtool.

sed -e 's/need_relink=yes/need_relink=no # no way --tml/' <ltmain.sh >ltmain.temp && mv ltmain.temp ltmain.sh

# Avoid using "file" in libtool. Otherwise libtool won't create a
# shared library, and give the warning "Trying to link with static lib
# archive [...] But I can only do this if you have shared version of
# the library, which you do not appear to have."

# I know what I am doing. I do want to link with a static libintl
# now. (The proxy-libintl libintl wrapper.)

sed -e 's!file /!dont-want-to-use-file!' <configure >configure.temp && mv configure.temp configure

CC='gcc -mtune=pentium3 -mms-bitfields -mthreads' \
CPPFLAGS="-I/devel/dist/${ARCH}/${PROXY_LIBINTL}/include \
-I/devel/dist/${ARCH}/${WIN_ICONV}/include \
-I/devel/dist/${ARCH}/${POPT}/include \
-I/devel/dist/${ARCH}/${LIBGNURX}/include \
-I/devel/dist/${ARCH}/${ZLIB}/include \
-I/devel/dist/${ARCH}/${PTHREADS}/include" \
LDFLAGS="-L/devel/dist/${ARCH}/${PROXY_LIBINTL}/lib -Wl,--exclude-libs=libintl.a \
-L/devel/dist/${ARCH}/${WIN_ICONV}/lib -Wl,--exclude-libs=libiconv.a \
-L/devel/dist/${ARCH}/${POPT}/lib \
-L/devel/dist/${ARCH}/${LIBGNURX}/lib \
-L/devel/dist/${ARCH}/${ZLIB}/lib \
-L/devel/dist/${ARCH}/${PTHREADS}/lib \
-Wl,--enable-auto-image-base" \
CFLAGS=-O2 \
./configure --disable-scrollkeeper --without-help --disable-static --enable-exchange=yes --enable-plugins=base \
--with-sub-version="tml@iki.fi ${THIS} `date +%Y%m%d`" \
--with-nspr-includes="/devel/dist/${ARCH}/${NSPR}/include" \
--with-nspr-libs="/devel/dist/${ARCH}/${NSPR}/lib" \
--with-nss-includes="/devel/dist/${ARCH}/${NSS}/include" \
--with-nss-libs="/devel/dist/${ARCH}/${NSS}/lib" \
--with-gconf-source='xml::${sysconfdir}/gconf/gconf.xml.defaults' \
--prefix=c:/devel/target/$HEX &&

libtoolcacheize &&

mkdir -p /devel/target/$HEX/etc/gconf/gconf.xml.defaults &&

PATH=/devel/target/$HEX/bin:.libs:$PATH make -j2 install &&
(cd po; make install; true) &&
make install-am &&

./evolution-zip &&

mv /tmp/${MOD}-${VER}.zip /tmp/$RUNZIP &&
mv /tmp/${MOD}-dev-${VER}.zip /tmp/$DEVZIP

) 2>&1 | tee /devel/src/tml/make/$THIS.log

(cd /devel && zip /tmp/$DEVZIP src/tml/make/$THIS.{sh,log}) &&
manifestify /tmp/$RUNZIP /tmp/$DEVZIP
