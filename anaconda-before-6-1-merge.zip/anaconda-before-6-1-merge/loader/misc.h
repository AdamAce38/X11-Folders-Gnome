#ifndef H_LOADER_MISC_H
#define H_LOADER_MISC_H

int copyFile(char * source, char * dest);

#endif
