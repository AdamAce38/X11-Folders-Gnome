import gettext

INSTALL_OK = 0
INSTALL_BACK = -1
INSTALL_NOOP = -2

cat = gettext.Catalog ("anaconda", "/usr/share/locale")
_ = cat.gettext

basicButtons = ((_("Ok"), "ok"), (_("Back"), "back"))
