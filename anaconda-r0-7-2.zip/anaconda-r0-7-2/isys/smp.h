#ifndef SMP_H
#define SMP_H

int detectSMP(void);

#endif /* SMP_H */
