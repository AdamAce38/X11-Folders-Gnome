#ifndef H_LOADER_PCMCIA
#define H_LOADER_PCMCIA

void startPcmcia(moduleList modLoaded, moduleDeps modDeps, int flags);

#endif
