#ifndef H_MOUNT
#define H_MOUNT

int catCommand(int argc, char ** argv);
int chmodCommand(int argc, char ** argv);
int dfCommand(int argc, char ** argv);
int gunzipCommand(int argc, char ** argv);
int lnCommand(int argc, char ** argv);
int lsCommand(int argc, char ** argv);
int lsmodCommand(int argc, char ** argv);
int mkdirCommand(int argc, char ** argv);
int mknodCommand(int argc, char ** argv);
int mountCommand(int argc, char ** argv);
int rmCommand(int argc, char ** argv);
int umountCommand(int argc, char ** argv);
int uncpioCommand(int argc, char ** argv);

#endif
