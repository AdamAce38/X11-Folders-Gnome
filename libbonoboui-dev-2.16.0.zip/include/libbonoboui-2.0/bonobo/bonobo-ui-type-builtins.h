
/* Generated data (by glib-mkenums) */

#ifndef __BONOBO_UI_TYPE_BUILTINS_H__
#define __BONOBO_UI_TYPE_BUILTINS_H__ 1

#include <glib-object.h>

G_BEGIN_DECLS


/* --- bonobo-dock-item.h --- */
#define BONOBO_TYPE_DOCK_ITEM_BEHAVIOR bonobo_dock_item_behavior_get_type()
GType bonobo_dock_item_behavior_get_type (void);

/* --- bonobo-dock.h --- */
#define BONOBO_TYPE_DOCK_PLACEMENT bonobo_dock_placement_get_type()
GType bonobo_dock_placement_get_type (void);

/* --- bonobo-ui-engine.h --- */
#define BONOBO_TYPE_UI_ERROR bonobo_ui_error_get_type()
GType bonobo_ui_error_get_type (void);

/* --- bonobo-ui-toolbar-item.h --- */
#define BONOBO_TYPE_UI_TOOLBAR_ITEM_STYLE bonobo_ui_toolbar_item_style_get_type()
GType bonobo_ui_toolbar_item_style_get_type (void);

/* --- bonobo-ui-toolbar.h --- */
#define BONOBO_TYPE_UI_TOOLBAR_STYLE bonobo_ui_toolbar_style_get_type()
GType bonobo_ui_toolbar_style_get_type (void);
G_END_DECLS

#endif /* __BONOBO_UI_TYPE_BUILTINS_H__ */

/* Generated data ends here */

