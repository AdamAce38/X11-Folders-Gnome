# This is a shell script that calls functions and scripts from
# tml@iki.fi's personal work environment. It is not expected to be
# usable unmodified by others, and is included only for reference.

MOD=tango-icon-theme
VER=0.8.1
THIS=$MOD-$VER
HEX=`echo $THIS | md5sum | cut -d' ' -f1`

DEPS=`/devel/src/tml/latest.sh icon-naming-utils`

usestable

MY_PKG_CONFIG_PATH=""
for D in $DEPS; do
    [ -d /devel/dist/$D/bin ] && PATH=/devel/dist/$D/bin:$PATH
    [ -d /devel/dist/$D/share/pkgconfig ] && MY_PKG_CONFIG_PATH=/devel/dist/$D/share/pkgconfig:$MY_PKG_CONFIG_PATH
    [ -d /devel/dist/$D/lib/pkgconfig ] && MY_PKG_CONFIG_PATH=/devel/dist/$D/lib/pkgconfig:$MY_PKG_CONFIG_PATH
done

PERL=$INTLTOOL_PERL PKG_CONFIG_PATH=$MY_PKG_CONFIG_PATH:$PKG_CONFIG_PATH CC='gcc -mtune=pentium3' ./configure --disable-icon-framing --prefix=c:/devel/target/$HEX &&
PERL=$INTLTOOL_PERL make install &&
(cd /devel/target/$HEX &&
rm -f /tmp/$MOD-$VER.zip /tmp/$MOD-dev-$VER.zip &&
zip -r /tmp/$MOD-$VER.zip share) &&
(cd /devel/src/tml && zip /tmp/$MOD-dev-$VER.zip make/$THIS.sh) &&
manifestify /tmp/$MOD-$VER.zip /tmp/$MOD-dev-$VER.zip

