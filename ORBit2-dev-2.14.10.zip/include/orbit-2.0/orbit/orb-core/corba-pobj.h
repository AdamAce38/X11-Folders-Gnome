#ifndef CORBA_POBJ_H
#define CORBA_POBJ_H 1

#include <orbit/util/orbit-util.h>
#include <orbit/orb-core/corba-typecode-type.h>

#endif
