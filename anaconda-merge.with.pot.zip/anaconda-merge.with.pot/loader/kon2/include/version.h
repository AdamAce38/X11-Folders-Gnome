#define VERSION "ver.0.3.8 (98/03/09)"
