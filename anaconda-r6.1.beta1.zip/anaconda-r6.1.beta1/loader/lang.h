#ifndef _LANG_H_
#define _LANG_H_

#define _(x) x
#define N_(foo) (foo)

#endif /* _LANG_H_ */
